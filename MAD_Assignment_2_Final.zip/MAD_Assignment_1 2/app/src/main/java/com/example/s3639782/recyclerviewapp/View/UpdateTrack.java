package com.example.s3639782.recyclerviewapp.View;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.s3639782.recyclerviewapp.Db.FoodTruckDatabaseHelper;
import com.example.s3639782.recyclerviewapp.Model.Tracking_FoodTruck;
import com.example.s3639782.recyclerviewapp.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class UpdateTrack extends AppCompatActivity implements OnMapReadyCallback {

    private ArrayList<String> trackingFoodTrucks = new ArrayList<String>();

    private Spinner spinnerD;
    private Spinner spinnerT;
    private Spinner spinnerYourTime;
    private static final int MY_REQUEST_INT = 177;
    private ArrayAdapter<String> adapterA;
    private ArrayAdapter<String> adapterB;
    private ArrayAdapter<String> adapterC;
    private ArrayList<String> showDate;
    private ArrayList<String> showTime;
    private ArrayList<String> duration;
    private ArrayList<Double> longitude;
    private ArrayList<Double> latitude;
    private ArrayList<String> yourTimes;
    private GoogleMap myMap;
    private ArrayList<Tracking_FoodTruck> trackinglist = new ArrayList<Tracking_FoodTruck>();
    private String currentDateSelected;
    private HashMap<Integer, String> dateTimeMap = null;
    private LatLng foodTruckLtLng;
    private Marker foodTruckMarker;
    private String timeString;
    private String truckId;
    private String foodTruckName;
    private String timeSelected;
    private Double truckLatValue = -37.8110;
    private Double truckLongValue = 144.9738;
    private FoodTruckDatabaseHelper ftDbHelper = null;
    private String meetingTime;
    Date currentTime = Calendar.getInstance().getTime();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track);


        ftDbHelper = new FoodTruckDatabaseHelper(this);

        Button b1 = (Button) findViewById(R.id.Updatebutton);


        ConnectivityManager cm = (ConnectivityManager)getSystemService(this.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        final boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean isSaved = false;

                isSaved = ftDbHelper.addTrackingItem(truckId, foodTruckName, currentDateSelected, timeSelected,
                        meetingTime, String.valueOf(truckLatValue), String.valueOf(truckLongValue));
                //Show error is not saved in db
                if (isSaved) {
                    Log.d("Database", "Tracking List data saved successfully in table");
                    Log.i("SHOW", "ID" + truckId);
                    Log.i("SHOW", "Name" + foodTruckName);
                    Log.i("SHOW", "CurrDate" + currentDateSelected);
                    Log.i("SHOW", "StartTime" + timeSelected);
                    Log.i("SHOW", "MeetingTime" + meetingTime);
                    Log.i("SHOW", "latitude" + truckLatValue);
                    Log.i("SHOW", "longitude" + truckLongValue);
                }

                Toast.makeText(UpdateTrack.this, "The item is added to Tracking List", Toast.LENGTH_SHORT).show();


                Intent intent3 = new Intent(UpdateTrack.this, MainActivity.class);

                startActivity(intent3);


                if (isConnected) {
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(UpdateTrack.this, "Time to go to the: " + foodTruckName + " at " + currentTime, Toast.LENGTH_SHORT).show();

                        }
                    }, 30000);
                }

            }
        });


        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView2);
        mapFragment.getMapAsync(this);


        spinnerD = (Spinner) findViewById(R.id.TDate);
        spinnerT = (Spinner) findViewById(R.id.Tetime);
        spinnerYourTime = (Spinner) findViewById(R.id.YourTime);
        Bundle bundle = getIntent().getExtras();
        truckId = bundle.getString("id");
        foodTruckName = bundle.getString("foodtruckname");
        TextView textViewName = (TextView) findViewById(R.id.Ttext);
        textViewName.setText(foodTruckName);

        Cursor cursor = ftDbHelper.getAllFoodTracksById(truckId);

        //iterate through all the rows contained in the database
        if(!cursor.moveToNext()){
            Toast.makeText(this, "There are no tracking data to show", Toast.LENGTH_SHORT).show();
        }


        showDate = new ArrayList<String>();
        showTime = new ArrayList<String>();
        duration = new ArrayList<String>();
        longitude = new ArrayList<Double>();
        latitude = new ArrayList<Double>();
        yourTimes = new ArrayList<String>();


        while(cursor.moveToNext()){

            showDate.add(cursor.getString(1));
            showTime.add(cursor.getString(3));
            duration.add(cursor.getString(4));
            longitude.add(cursor.getDouble(6));
            latitude.add(cursor.getDouble(5));
        }

        dateTimeMap = new HashMap<Integer, String>();
        ArrayList<String> displayDates = new ArrayList<String>();
        for(int i=0; i<showDate.size(); i++){
            Log.d("Debug", "Date is : " + showDate.get(i));

            String dur = duration.get(i);

            if(Integer.valueOf(dur) > 0){

                String date = showDate.get(i);
                Log.d("Debug", "Date value : " + date);
                String time = showTime.get(i);
                Log.d("Debug", "Time value : " + time);

                if(!displayDates.contains(date)) {
                    displayDates.add(date);
                }

                dateTimeMap.put(i, date + "," + time + "," + String.valueOf(i));
            }
        }


        adapterA = new ArrayAdapter<String>(UpdateTrack.this, android.R.layout.simple_spinner_dropdown_item, displayDates);

        spinnerD.setAdapter(adapterA);

        spinnerD.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                currentDateSelected = parent.getItemAtPosition(position).toString(); //this is your selected item
                Log.d("Debug", "Date selected is : " + currentDateSelected);
                ArrayList<String> displayTimeList = validateTimeForDate(dateTimeMap, currentDateSelected);
                Log.d("Debug", "Display Time List is  : " + displayTimeList);
                adapterB = new ArrayAdapter<String>(UpdateTrack.this, android.R.layout.simple_spinner_dropdown_item, displayTimeList);
                spinnerT.setAdapter(adapterB);
            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });


        spinnerT.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {

                timeSelected = parent.getItemAtPosition(position).toString(); //this is your selected item
                for(Map.Entry<Integer, String> entry : dateTimeMap.entrySet()){

                    String value = entry.getValue();

                    String[] values = value.split(",");
                    String date = values[0];
                    String time = values[1];
                    String indexVal = values[2];

                    Log.d("Debug", "Date : " + date + " Time : " + time);

                    if(currentDateSelected.equals(date) && timeSelected.equals(time)){
                        truckLatValue = latitude.get(Integer.valueOf(indexVal));
                        truckLongValue = longitude.get(Integer.valueOf(indexVal));


                        Log.d("Debug", "Found match lat value : " + truckLatValue
                                + " long value : " + truckLongValue);

                        foodTruckLtLng = new LatLng(truckLatValue, truckLongValue);
                        foodTruckMarker = myMap.addMarker(new MarkerOptions().position(foodTruckLtLng)
                                .title(foodTruckName));

                        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(foodTruckLtLng, 15.0f));

                        String stoppingDuration = duration.get(Integer.valueOf(indexVal));
                        setYourTimesList(timeSelected, stoppingDuration);
                    }

                }

            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });


        Cursor cursor1 = ftDbHelper.getAllFoodTracksById(truckId);

        //iterate through all the rows contained in the database
        if(!cursor1.moveToNext()){
            Toast.makeText(this, "There are no tracking data to show", Toast.LENGTH_SHORT).show();
        }

    }

    void setYourTimesList(String timeSelected, String stopDuration){

        System.out.println("Before Time : " + timeSelected + "\n");
        System.out.println("Stop duration : " + stopDuration + "\n");

        SimpleDateFormat df = new SimpleDateFormat("hh:mm:ss a");
        int minutesToAdd = Integer.valueOf(stopDuration);

        Calendar startTime = Calendar.getInstance();
        try{

            yourTimes.clear();
            String st = new String(timeSelected);
            timeSelected = new StringBuffer(st).insert(st.length() - 2, " ").toString();
            System.out.println("New Before Time : " + timeSelected + "\n");

            yourTimes.add(timeSelected);

            String timStr = "";
            for(int i=0; i<Integer.valueOf(stopDuration); i++) {

                if(i==0) {
                    startTime.setTime(df.parse(timeSelected));
                } else {
                    System.out.println("Add to new timestring : " + timStr + "\n");
                    startTime.setTime(df.parse(timStr));
                }
                startTime.add(startTime.MINUTE, 1);
                timeString = df.format(startTime.getTime());
                System.out.println("After Time : " + timeString + "\n");

                timStr = timeString;
                yourTimes.add(timeString);
            }

        } catch (Exception e){
            Log.d("ERROR", "Error parsing date");
        }

        Log.d("Debug", "Your Times List : " + yourTimes);


        adapterC = new ArrayAdapter<String>(UpdateTrack.this, android.R.layout.simple_spinner_dropdown_item, yourTimes);
        spinnerYourTime.setAdapter(adapterC);



        spinnerYourTime.setOnItemSelectedListener(new OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {

                meetingTime = parent.getItemAtPosition(position).toString(); //this is your selected item


            }
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });


    }


    //Validation of time specific to date selected
    ArrayList<String> validateTimeForDate(HashMap<Integer, String> dateTimeMap, String dateToMatch){

        ArrayList<String> displayTimeList = new ArrayList<String>();

        for(Map.Entry<Integer, String> entry : dateTimeMap.entrySet()){
            Integer index = entry.getKey();
            String value = entry.getValue();

            String[] values = value.split(",");
            String date = values[0];
            String time = values[1];

            Log.d("Debug", "Date : " + date + " Time : " + time);

            if(dateToMatch.equals(date)){
                displayTimeList.add(time);
            }

        }

        return displayTimeList;
    }


    @Override
    public void onMapReady(GoogleMap map) {

        this.myMap = map;


        LatLng RMIT = new LatLng(-37.8110, 144.9738);
        Marker A = myMap.addMarker(new MarkerOptions().position(RMIT)
                .title(foodTruckName));


        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(RMIT, 15.0f));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

            if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION},MY_REQUEST_INT);
            }
            return;
        }
        else{

            myMap.setMyLocationEnabled(true);

        }

    }
}
