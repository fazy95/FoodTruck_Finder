package com.example.s3639782.recyclerviewapp.View;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.TextView;

import com.example.s3639782.recyclerviewapp.Model.Tracking_FoodTruck;
import com.example.s3639782.recyclerviewapp.R;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TrackingService extends AppCompatActivity {

    private BufferedReader br;
    private ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    private ArrayList<String> strings = new ArrayList<String>();
    private ArrayList<Tracking_FoodTruck> trackingFoodTrucks = new ArrayList<Tracking_FoodTruck>();


    ArrayList<String> Lines = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking_schedule);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;

        getWindow().setLayout((int) (width * .8), (int) (height * .7));


        Bundle bundle = getIntent().getExtras();

        String truckId = bundle.getString("id");


        TextView schedule = (TextView) findViewById(R.id.schedule);

        int i;


        fileReadTrackingService();


        String a = "";

        for (int p = 0; p < Lines.size(); p++) {

            schedule.setText("");

            if (truckId.equals(trackingFoodTrucks.get(p).getTrackableId())) {
                a = a + "\n" + "Date :" + trackingFoodTrucks.get(p).getDatef() + "\n"
                        + "Stop Time :" + trackingFoodTrucks.get(p).getStopTime() + "\n"
                        + "Duration: " + trackingFoodTrucks.get(p).getDuration() + "\n"
                        + "Latitude :" + trackingFoodTrucks.get(p).getLatitude() + "\n"
                        + "Longitude :" + trackingFoodTrucks.get(p).getLongitude() + "\n";

            }
        }

        schedule.setText(a);

    }

    private void fileReadTrackingService() {
        InputStream inputStream = getResources().openRawResource(R.raw.tracking_data);
        String ret = "";
        String[] item = new String[2000];
        ArrayList<String> Line = new ArrayList<String>();


        try {

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                while ((ret = bufferedReader.readLine()) != null) {
                    Lines.add(ret);

                    trackingFoodTrucks.add(new Tracking_FoodTruck());
                }

            }
        } catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        int y = 0;
        int x = 0;
        for (int j = 0; j < trackingFoodTrucks.size(); j++) {
            item = Lines.get(j).split("#");

            List<String> itemList = new ArrayList<String>(Arrays.asList(item));
            trackingFoodTrucks.get(j).setDatef(itemList.get(y));
            trackingFoodTrucks.get(j).setStopTime(itemList.get(y + 1));
            trackingFoodTrucks.get(j).setTrackableId(itemList.get(y + 2));
            trackingFoodTrucks.get(j).setDuration(itemList.get(y + 3));
            trackingFoodTrucks.get(j).setLatitude(itemList.get(y + 4));
            trackingFoodTrucks.get(j).setLongitude((itemList.get(y + 5)));


            x++;
        }
    }
}

