package com.example.s3639782.recyclerviewapp.Model;

public class FoodTruck {
    private String name;
    private String id;
    private String desc;
    private String url;
    private String category;
    private int image;


    public FoodTruck(){}

    public FoodTruck(String name, String id, String desc, String url, String category, int image) {
        this.name = name;
        this.id = id;
        this.desc = desc;
        this.url = url;
        this.category = category;
        this.image =image;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
