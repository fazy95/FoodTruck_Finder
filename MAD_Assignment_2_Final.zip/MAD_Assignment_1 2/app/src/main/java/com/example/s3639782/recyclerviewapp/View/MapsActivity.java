package com.example.s3639782.recyclerviewapp.View;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.widget.TextView;

import com.example.s3639782.recyclerviewapp.Model.DFListener;
import com.example.s3639782.recyclerviewapp.Model.LocationSearch;
import com.example.s3639782.recyclerviewapp.R;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, DFListener {

    private GoogleMap Map;
    private List<Marker> stPoints = new ArrayList<>();
    private List<Marker> endPoints = new ArrayList<>();
    private List<Polyline> polyWays = new ArrayList<>();
    private ProgressDialog prgrsInfo;
    private String foodTruckLat;
    private String foodTruckLong;
    private String origin;
    private String destination;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        LocationManager lm = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        @SuppressLint("MissingPermission")
        Location ltn = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        double longitude1 = ltn.getLongitude();
        double latitude1 = ltn.getLatitude();
        String longitude2 = Double.toString(longitude1);
        String latitude2 = Double.toString(latitude1);

        foodTruckLat = latitude2;
        foodTruckLong =longitude2;
        origin = foodTruckLat + "," + foodTruckLong;


        Bundle bundle = getIntent().getExtras();

        String ftLat = bundle.getString("foodtruckLat");
        String ftLng = bundle.getString("foodtruckLong");

        //destination = "-37.8101,144.9552";
        destination = ftLat +  "," + ftLng;
        Log.d("ROUTEMAP", "Origin : " + origin + " Dest : " + destination);

        accessRequest();

    }

    private void accessRequest() {

        try {
            new LocationSearch(this, origin, destination).execute();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Map = googleMap;
        LatLng RMIT = new LatLng(-37.890475, 144.765121);
        Map.moveCamera(CameraUpdateFactory.newLatLngZoom(RMIT, 18));
        stPoints.add(Map.addMarker(new MarkerOptions()
                .title("RMIT")
                .position(RMIT)));

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Map.setMyLocationEnabled(true);
    }


    @Override
    public void onDFBegin() {
        prgrsInfo = ProgressDialog.show(this, "Loading",
                "Looking for your route...", true);

        if (stPoints != null) {
            for (Marker marker : stPoints) {
                marker.remove();
            }
        }

        if (endPoints != null) {
            for (Marker marker : endPoints) {
                marker.remove();
            }
        }

        if (polyWays != null) {
            for (Polyline polyline: polyWays) {
                polyline.remove();
            }
        }
    }

    @Override
    public void onDFConfirm(List<LocationSearch.Route> routes) {
        prgrsInfo.dismiss();
        polyWays = new ArrayList<>();
        stPoints = new ArrayList<>();
        endPoints = new ArrayList<>();

        for (LocationSearch.Route route : routes) {
            Map.moveCamera(CameraUpdateFactory.newLatLngZoom(route.startLoc, 15.0f));
            ((TextView) findViewById(R.id.tvDuration)).setText(route.dur.text);
            ((TextView) findViewById(R.id.tvDistance)).setText(route.dst.text);

            stPoints.add(Map.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.startpin))
                    .title(route.startAdd)
                    .position(route.startLoc)));
            endPoints.add(Map.addMarker(new MarkerOptions()
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.endpin))
                    .title(route.endAdd)
                    .position(route.endLoc)));

            PolylineOptions polylineOptions = new PolylineOptions().
                    geodesic(true).
                    color(Color.BLUE).
                    width(12);

            for (int i = 0; i < route.pts.size(); i++)
                polylineOptions.add(route.pts.get(i));

            polyWays.add(Map.addPolyline(polylineOptions));
        }
    }
}
