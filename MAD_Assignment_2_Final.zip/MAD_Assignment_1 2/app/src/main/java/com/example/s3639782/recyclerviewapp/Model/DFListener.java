package com.example.s3639782.recyclerviewapp.Model;

import java.util.List;


public interface DFListener {           //To listen for direction route events
    void onDFBegin();
    void onDFConfirm(List<LocationSearch.Route> rts);
}