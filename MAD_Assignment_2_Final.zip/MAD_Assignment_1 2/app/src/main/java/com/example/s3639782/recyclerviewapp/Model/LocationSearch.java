package com.example.s3639782.recyclerviewapp.Model;

import android.os.AsyncTask;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;


public class LocationSearch {
    private static final String DIRECTION_URL_API = "https://maps.googleapis.com/maps/api/directions/json?";
    private static final String GOOGLE_API_KEY1 = "AIzaSyAU731Txkeg4WSf8NT47fMJHrkxhCVSLNU";
    private DFListener dfListener;
    private String origin;
    private String destination;

    public LocationSearch(DFListener dfListener, String origin, String destination) {
        this.dfListener = dfListener;
        this.origin = origin;
        this.destination = destination;
    }

    public void execute() throws UnsupportedEncodingException {
        dfListener.onDFBegin();
        new getMapData().execute(buildUrl());
    }

    private String buildUrl() throws UnsupportedEncodingException {
        String urlOrigin = URLEncoder.encode(origin, "utf-8");
        String urlDestination = URLEncoder.encode(destination, "utf-8");

        //return DIRECTION_URL_API + "origin=" + urlOrigin + "&destination=" + urlDestination + "&key=" + GOOGLE_API_KEY;

        //return DIRECTION_URL_API + "origin=-37.890475,144.765121"  + "&destination=-37.861194,144.742539" + "&key=" + GOOGLE_API_KEY;
        Log.i("dud",origin+destination+GOOGLE_API_KEY1+"");
        return DIRECTION_URL_API + "origin=" + origin  + "&destination=" + destination + "&key=" + GOOGLE_API_KEY1;

    }

    private class getMapData extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            //Using AsyncTask to create URL and send to JS API
            String link = params[0];
            try {
                URL url = new URL(link);
                InputStream is = url.openConnection().getInputStream();
                StringBuffer buffer = new StringBuffer();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));


                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line + "\n");
                }


                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                parseJSONQuery(result);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    //Parsing JSON Query into string variable returned from API
    private void parseJSONQuery(String data) throws JSONException {
        if (data == null)
            return;

        List<Route> rts = new ArrayList<Route>();
        JSONObject jsonInfo = new JSONObject(data);
        JSONArray jsonRts = jsonInfo.getJSONArray("routes");
        for (int i = 0; i < jsonRts.length(); i++) {
            JSONObject jsonRt = jsonRts.getJSONObject(i);
            Route rt = new Route();

            JSONObject polylineJson = jsonRt.getJSONObject("overview_polyline");
            JSONArray Legs = jsonRt.getJSONArray("legs");
            JSONObject Leg = Legs.getJSONObject(0);
            JSONObject Distance = Leg.getJSONObject("distance");
            JSONObject Duration = Leg.getJSONObject("duration");
            JSONObject EndLocation = Leg.getJSONObject("end_location");
            JSONObject StartLocation = Leg.getJSONObject("start_location");

            rt.dst = new Distance(Distance.getString("text"), Distance.getInt("value"));
            rt.dur = new Duration(Duration.getString("text"), Duration.getInt("value"));
            rt.endAdd = Leg.getString("end_address");
            rt.startAdd = Leg.getString("start_address");
            rt.startLoc = new LatLng(StartLocation.getDouble("lat"), StartLocation.getDouble("lng"));
            rt.endLoc = new LatLng(EndLocation.getDouble("lat"), EndLocation.getDouble("lng"));
            rt.pts = decodePolyLine(polylineJson.getString("points"));

            rts.add(rt);
        }

        dfListener.onDFConfirm(rts);
    }

    //Create list of points to create polyline from start - end position
    private List<LatLng> decodePolyLine(final String polyline) {
        int len = polyline.length();
        int index = 0;
        List<LatLng> latlnglist = new ArrayList<LatLng>();
        int lat = 0;
        int lng = 0;

        while (index < len) {
            int b;
            int shift = 0;
            int result = 0;
            do {
                b = polyline.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = polyline.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            latlnglist.add(new LatLng(
                    lat / 100000d, lng / 100000d
            ));
        }

        return latlnglist;
    }

    //Route class to hold data from start position to destination
    public static class Route {
        public Distance dst;
        public Duration dur;
        public String endAdd;
        public LatLng endLoc;
        public String startAdd;
        public LatLng startLoc;

        public List<LatLng> pts;
    }

    //Data class holds time from start point to destination
    public static class Duration {
        public String text;
        public int value;

        public Duration(String text, int value) {
            this.text = text;
            this.value = value;
        }
    }
 //Distance class holds the distance in kms from start point to end point
    public static class Distance {
        public String text;
        public int value;

        public Distance(String text, int value) {
            this.text = text;
            this.value = value;
        }
    }
}
