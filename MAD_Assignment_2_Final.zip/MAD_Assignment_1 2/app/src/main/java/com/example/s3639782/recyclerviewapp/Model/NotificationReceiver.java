package com.example.s3639782.recyclerviewapp.Model;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import android.util.Log;

public class NotificationReceiver extends BroadcastReceiver {

    //Recieves broadcast from SuggestAlert

    @Override
    public void onReceive(Context context, Intent intent) {

/*        String action = intent.getAction();
        Log.d("DEBUG", "Action received : " + action);
        Toast.makeText(context, action, Toast.LENGTH_SHORT).show();*/

        int notificationId = intent.getIntExtra("notificationId", 0);
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancel(notificationId);
    }
}
