package com.example.s3639782.recyclerviewapp.Db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.s3639782.recyclerviewapp.Model.FoodTruck;
import com.example.s3639782.recyclerviewapp.Model.Tracking;
import com.example.s3639782.recyclerviewapp.Model.Tracking_FoodTruck;

import java.util.ArrayList;
import java.util.List;


public class FoodTruckDatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "FoodTruckDatabaseHelper";

    private static final String DATABASE_NAME = "foodtruck.db";
    private static final String FT_TABLE_NAME = "foodtruck_table";
    private static final String FTS_TABLE_NAME = "foodtrucktracking_table";
    private static final String TLIST_TABLE_NAME = "trackinglist_table";


    //FT Table Columns
    public static final String COL0 = "ID";
    public static final String COL1 = "NAME";
    public static final String COL2 = "DESCRIPTION";
    public static final String COL3 = "URL";
    public static final String COL4 = "CATEGORY";
    public static final String COL5 = "IMAGE";
    public static final String COL99 = "TRUCKID";

    //FTS Table Columns
    public static final String COL6 = "ID";
    public static final String COL7 = "DATE";
    public static final String COL8 = "TRACKID";
    public static final String COL9 = "STARTTIME";
    public static final String COL10 = "DURATION";
    public static final String COL11 = "LATITUDE";
    public static final String COL12 = "LONGITUDE";


    //TLIST Table Columns
    public static final String COL13 = "ID";
    public static final String COL14 = "TRACKID";
    public static final String COL15 = "NAME";
    public static final String COL16 = "DATE";
    public static final String COL17 = "STARTTIME";
    public static final String COL18 = "MEETINGTIME";
    public static final String COL19 = "LATITUDE";
    public static final String COL20 = "LONGITUDE";

    public FoodTruckDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql1 = "CREATE TABLE " +
                FT_TABLE_NAME + " ( " +
                COL0 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL1 + " TEXT, " +
                COL2 + " TEXT, " +
                COL3 + " TEXT, " +
                COL4 + " TEXT, " +
                COL5 + " TEXT, " +
                COL99 + " TEXT )";

        db.execSQL(sql1);


        String sql2 = "CREATE TABLE " +
                FTS_TABLE_NAME + " ( " +
                COL6 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL7 + " TEXT, " +
                COL8 + " TEXT, " +
                COL9 + " TEXT, " +
                COL10 + " TEXT, " +
                COL11 + " TEXT, " +
                COL12 + " TEXT )";


        db.execSQL(sql2);


        String sql3 = "CREATE TABLE " +
                TLIST_TABLE_NAME + " ( " +
                COL13 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL14 + " TEXT, " +
                COL15 + " TEXT, " +
                COL16 + " TEXT, " +
                COL17 + " TEXT, " +
                COL18 + " TEXT, " +
                COL19 + " TEXT, " +
                COL20 + " TEXT )";


        db.execSQL(sql3);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF TABLE EXISTS " + FT_TABLE_NAME);
        db.execSQL("DROP IF TABLE EXISTS " + FTS_TABLE_NAME);
        db.execSQL("DROP IF TABLE EXISTS " + TLIST_TABLE_NAME);
        onCreate(db);
    }




    //FT Table Queries


    /**
     * Insert a new foodTruck instance into the database
     *
     * @param
     * @return
     */
    public boolean addFoodTruck(FoodTruck foodTruck) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, foodTruck.getName());
        contentValues.put(COL2, foodTruck.getDesc());
        contentValues.put(COL3, foodTruck.getImage());
        contentValues.put(COL4, foodTruck.getUrl());
        contentValues.put(COL5, foodTruck.getCategory());
        contentValues.put(COL99, foodTruck.getId());

        long result = db.insert(FT_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addFoodTrucks(ArrayList<FoodTruck> foodTrucks) {
        SQLiteDatabase db = this.getWritableDatabase();

        boolean returnValue = false;

        for (FoodTruck foodTruck : foodTrucks) {

            ContentValues contentValues = new ContentValues();
            contentValues.put(COL1, foodTruck.getName());
            contentValues.put(COL2, foodTruck.getDesc());
            contentValues.put(COL3, foodTruck.getImage());
            contentValues.put(COL4, foodTruck.getUrl());
            contentValues.put(COL5, foodTruck.getCategory());
            contentValues.put(COL99, foodTruck.getId());

            long result = db.insert(FT_TABLE_NAME, null, contentValues);

            if (result == -1) {
                return false;
            } else {
                returnValue = true;
            }
        }

        return returnValue;
    }

    /**
     * Retrieve all food trucks from database
     *
     * @return
     */
    public Cursor getAllFoodTrucks() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + FT_TABLE_NAME, null);
    }

    /**
     * Update a foodtruck where id = @param 'id'
     * Replace the current foodtruck with @param 'foodtruck'
     *
     * @param
     * @param id
     * @return
     */
    public boolean updateFoodTruck(FoodTruck foodTruck, int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, foodTruck.getName());
        contentValues.put(COL2, foodTruck.getCategory());
        contentValues.put(COL3, foodTruck.getDesc());
        contentValues.put(COL4, foodTruck.getUrl());
        contentValues.put(COL5, foodTruck.getImage());

        int update = db.update(FT_TABLE_NAME, contentValues, COL0 + " = ? ", new String[]{String.valueOf(id)});

        if (update != 1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Retrieve the FoodTruck unique id from the database using @param
     *
     * @param foodTruck
     * @return
     */
    public Cursor getFoodTruckID(FoodTruck foodTruck) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM " + FT_TABLE_NAME +
                " WHERE " + COL1 + " = '" + foodTruck.getName() + "'" +
                " AND " + COL2 + " = '" + foodTruck.getCategory() + "'";
        return db.rawQuery(sql, null);
    }

    public Integer deleteFoodTruck(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(FT_TABLE_NAME, "ID = ?", new String[]{String.valueOf(id)});
    }




    //FTS TABLE Queries

    /**
     * Insert a new foodTruck instance into the database
     *
     * @param
     * @return
     */
    public boolean addFoodTracking(Tracking_FoodTruck foodTrack) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL7, foodTrack.getDatef());
        contentValues.put(COL8, foodTrack.getTrackableId());
        contentValues.put(COL9, foodTrack.getStopTime());
        contentValues.put(COL10, foodTrack.getDuration());
        contentValues.put(COL11, foodTrack.getLatitude());
        contentValues.put(COL12, foodTrack.getLongitude());

        long result = db.insert(FTS_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addFoodTracks(ArrayList<Tracking_FoodTruck> foodTracks) {
        SQLiteDatabase db = this.getWritableDatabase();

        boolean returnValue = false;

        for (Tracking_FoodTruck foodTrack : foodTracks) {

            ContentValues contentValues = new ContentValues();
            contentValues.put(COL7, foodTrack.getDatef());
            contentValues.put(COL8, foodTrack.getTrackableId());
            contentValues.put(COL9, foodTrack.getStopTime());
            contentValues.put(COL10, foodTrack.getDuration());
            contentValues.put(COL11, foodTrack.getLatitude());
            contentValues.put(COL12, foodTrack.getLongitude());

            long result = db.insert(FTS_TABLE_NAME, null, contentValues);

            if (result == -1) {
                return false;
            } else {
                returnValue = true;
            }
        }

        return returnValue;
    }


    /**
     * Retrieve all food tracks from database
     *
     * @return
     */
    public Cursor getAllFoodTracks() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + FTS_TABLE_NAME, null);
    }

    /**
     * Retrieve all food tracks by id from database
     *
     * @return
     */
    public Cursor getAllFoodTracksById(String trackableID) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + FTS_TABLE_NAME +
                " WHERE " + COL8 + " =  " + trackableID, null);
    }

    /**
     * Update a foodtrack where id = @param 'id'
     * Replace the current foodtrack with @param 'foodtrack'
     *
     * @param
     * @param id
     * @return
     */
    public boolean updateFoodTrack(Tracking_FoodTruck foodTrack, int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL7, foodTrack.getDatef());
        contentValues.put(COL8, foodTrack.getTrackableId());
        contentValues.put(COL9, foodTrack.getStopTime());
        contentValues.put(COL10, foodTrack.getDuration());
        contentValues.put(COL11, foodTrack.getLatitude());
        contentValues.put(COL12, foodTrack.getLongitude());

        int update = db.update(FTS_TABLE_NAME, contentValues, COL8 + " = ? ", new String[]{String.valueOf(id)});

        if (update != 1) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Retrieve the FoodTrack unique id from the database using @param
     *
     * @param foodTrack
     * @return
     */
    public Cursor getFoodTrackID(Tracking_FoodTruck foodTrack) {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "SELECT * FROM " + FTS_TABLE_NAME +
                " WHERE " + COL8 + " = '" + foodTrack.getTrackableId() + "'" +
                " AND " + COL10 + " = '" + foodTrack.getDuration() + "'";
        return db.rawQuery(sql, null);
    }

    public Integer deleteFoodTrack(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(FTS_TABLE_NAME, "ID = ?", new String[]{String.valueOf(id)});
    }

    public Cursor getAllTrackingsBydate(String date, String startTime) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + FTS_TABLE_NAME +
                " WHERE " + COL7 + " =  " + date + " AND " + COL9 + " =  " + startTime, null);
    }





    //TLIST Table Queries

    /**
     * Insert a new tracking instance into the database (UPDATE BUTTON)
     *
     * @param
     * @return
     */
    public boolean addTracking(FoodTruck foodTruck, Tracking_FoodTruck foodTrack) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL14, foodTrack.getTrackableId());
        contentValues.put(COL15, foodTruck.getName());
        contentValues.put(COL16, foodTrack.getDatef());
        contentValues.put(COL17, foodTrack.getStopTime());
        contentValues.put(COL18, foodTrack.getMeetingTime());
        contentValues.put(COL19, foodTrack.getLatitude());
        contentValues.put(COL20, foodTrack.getLongitude());

        long result = db.insert(TLIST_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean addTrackingItem(String foodTruckId, String foodTruckName, String date,
                                   String stopTime, String meetingTime,
                                   String latitude, String longitude) {
        SQLiteDatabase db = this.getWritableDatabase();

        boolean returnValue = false;

        ContentValues contentValues = new ContentValues();
        contentValues.put(COL14, foodTruckId);
        contentValues.put(COL15, foodTruckName);
        contentValues.put(COL16, date);
        contentValues.put(COL17, stopTime);
        contentValues.put(COL18, meetingTime);
        contentValues.put(COL19, latitude);
        contentValues.put(COL20, longitude);

        long result = db.insert(TLIST_TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        } else {
            returnValue = true;
        }


        return  returnValue;

    }

    public boolean updateTrackingItem(String truckId, String foodTruckName, String date,
                                   String stopTime, String meetingTime) {
        SQLiteDatabase db = this.getWritableDatabase();

        boolean returnValue = false;

        ContentValues contentValues = new ContentValues();
        //contentValues.put(COL14, foodTruckId);
        contentValues.put(COL15, foodTruckName);
        contentValues.put(COL16, date);
        contentValues.put(COL17, stopTime);
        contentValues.put(COL18, meetingTime);
        //contentValues.put(COL19, latitude);
        //contentValues.put(COL20, longitude);

        //long result = db.insert(TLIST_TABLE_NAME, null, contentValues);

        int result = db.update(TLIST_TABLE_NAME, contentValues, COL14 + " = ? ", new String[]{truckId});

        if (result == -1) {
            return false;
        } else {
            returnValue = true;
        }


        return  returnValue;

    }

    /**
     * Retrieve all tracking item from database (GO TO TRACKING LIST BUTTON)
     * @return
     */
    public Cursor getAlltracking() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + TLIST_TABLE_NAME, null);
    }

    /**
     * Update a trackinglist (SAVE BUTTON) where id = @param 'id'
     * Replace the current tracking list item with @param 'foodtruck'
     * @param
     * @paramid
     * @return
     */
    public boolean updateTrackingList (FoodTruck foodTruck,int id, Tracking_FoodTruck foodTrack){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL14, foodTruck.getId());
        contentValues.put(COL15, foodTruck.getName());
        contentValues.put(COL16, foodTrack.getDatef());
        contentValues.put(COL17, foodTrack.getStopTime());
        contentValues.put(COL18, foodTrack.getMeetingTime());
        contentValues.put(COL19, foodTrack.getLatitude());
        contentValues.put(COL20, foodTrack.getLongitude());

        int update = db.update(TLIST_TABLE_NAME, contentValues, COL14 + " = ? ", new String[]{String.valueOf(id)});

        if (update != 1) {
            return false;
        } else {
            return true;
        }
    }


    /* Delete item from tracking list (DELETE BUTTON)  */

    public Integer deleteFoodTrackingList ( int id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TLIST_TABLE_NAME, "ID = ?", new String[]{String.valueOf(id)});
    }

    /* Delete item for matching date and meeting time */
    public Integer deleteFoodTrackingItem (String date, String meetingTime){

        SQLiteDatabase db = this.getWritableDatabase();

        return db.delete(TLIST_TABLE_NAME,
                COL16 + " = ? AND " + COL18 + " = ?",
                new String[] {date, meetingTime+""});
    }

}







