package com.example.s3639782.recyclerviewapp.View;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.s3639782.recyclerviewapp.Db.FoodTruckDatabaseHelper;
import com.example.s3639782.recyclerviewapp.R;

public class Truckdetail extends AppCompatActivity {

    private static final String TAG = "TruckDetail";
    private String name1;
    private String image1;
    private String id1;
    private String desc1;
    private String website1;
    private String category1;

    private String foodTruckName;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.truck_detail);
        Log.d(TAG, "onCreate: Started");

        getIncomingIntent();


        Button b2 = (Button) findViewById(R.id.Sbutton);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String truckname = name1;
                String truckID = id1;

                Intent thisIntent = new Intent(Truckdetail.this, TrackingService.class);

                Bundle bundle = new Bundle();
                bundle.putString("id", truckID);
                bundle.putString("name", truckname);

                thisIntent.putExtras(bundle);


                startActivity(thisIntent);
            }


        });

        Button b1 = (Button) findViewById(R.id.Trackbutton);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String truckID = id1;

                Intent myIntent = new Intent(Truckdetail.this, UpdateTrack.class);

                myIntent.putExtra("id", truckID);
                Log.i("Show", truckID);

                myIntent.putExtra("foodtruckname", name1);

                startActivity(myIntent);

            }
        });


    }



    private void getIncomingIntent() {

        if (getIntent().hasExtra("name") && getIntent().hasExtra("image")
                && getIntent().hasExtra("id") && getIntent().hasExtra("desc") && getIntent().hasExtra("website") &&
                getIntent().hasExtra("category")) {


            Log.d("SUC", "Received values in intent");


            name1 = getIntent().getStringExtra("name");
            Log.d("SUC", "Received values in intent for name : " + name1);

            String name2 = getIntent().getExtras().getString("name");

            Log.d("SUC", "Received values in intent for name : " + name2);


            image1 = getIntent().getStringExtra("image");
            id1 = getIntent().getStringExtra("id");
            desc1 = getIntent().getStringExtra("desc");
            website1 = getIntent().getStringExtra("website");
            category1 = getIntent().getStringExtra("category");


            setDetail(name1, image1, id1, desc1, website1, category1);

        } else {
            Log.d("ERR", "Did not receive values in intent");
        }
    }


    private void setDetail(String name, String image, String id, String desc, String website, String category) {

        TextView Tname = findViewById(R.id.Tname);
        Tname.setText(name1);

        ImageView Timage = findViewById(R.id.Timage);
        Timage.setImageResource(R.drawable.imlogo);

        TextView Tid = findViewById(R.id.Tid);
        Tid.setText(id1);

        TextView Tdesc = findViewById(R.id.Tdesc);
        Tdesc.setText(desc1);

        TextView Tweb = findViewById(R.id.Tweb);
        Tweb.setText(website1);

        TextView Tcat = findViewById(R.id.Tcat);
        Tcat.setText(category1);


    }


}




