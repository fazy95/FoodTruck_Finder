package com.example.s3639782.recyclerviewapp.View;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.s3639782.recyclerviewapp.Controller.myAdapter;
import com.example.s3639782.recyclerviewapp.Db.FoodTruckDatabaseHelper;
import com.example.s3639782.recyclerviewapp.Model.Tracking_FoodTruck;
import com.example.s3639782.recyclerviewapp.R;

import java.util.ArrayList;
import java.util.HashMap;

public class Tracked extends AppCompatActivity {


    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private ArrayList<Tracking_FoodTruck> trackingFoodTrucks;
    private Tracking_FoodTruck trackingFoodTruck;

    private String dateSelected;
    private String timeSelected;

    String id;
    String ftName;
    String date;
    String startTime;
    String meetingTime;
    String latVal;
    String longVal;


    private ArrayList<HashMap<String, Object>> foodTruckDataMap = new ArrayList<HashMap<String, Object>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tracked);

        Button button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextTrackingList = new Intent(Tracked.this, MainActivity.class);
                startActivity(nextTrackingList);
            }
        });


        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        trackingFoodTrucks = new ArrayList<>();

        FoodTruckDatabaseHelper ftDbHelper1 = new FoodTruckDatabaseHelper(Tracked.this);

        Cursor cursor = ftDbHelper1.getAlltracking();


        if (cursor.getCount() <= 0) {
            cursor.close();
            Toast.makeText(Tracked.this, "The tracking list is Empty", Toast.LENGTH_SHORT).show();
        } else {


            while (cursor.moveToNext()) {

                HashMap<String, Object> ftMap = new HashMap<String, Object>();

                id = cursor.getString(1);
                ftName = cursor.getString(2);
                date = cursor.getString(3);
                startTime = cursor.getString(4);
                meetingTime = cursor.getString(5);
                latVal = cursor.getString(6);
                longVal = cursor.getString(7);

                ftMap.put("id", id);
                ftMap.put("ftName", ftName);
                ftMap.put("date", date);
                ftMap.put("startTime", startTime);
                ftMap.put("meetingTime", meetingTime);
                ftMap.put("latitude", latVal);
                ftMap.put("longitude", longVal);


                Log.d("Info1", "Values are : " + ftMap);

                foodTruckDataMap.add(ftMap);
            }


            //Run a loop to create the Food Truck options and add to trackingFoodTrucks


            trackingFoodTrucks.add(new Tracking_FoodTruck(

                    ftName,
                    date,
                    id,
                    startTime,
                    "*latVal*",
                    "*longVal", " ", meetingTime
            ));

        }

        adapter = new myAdapter.trackingAdapter(foodTruckDataMap, this);
        recyclerView.setAdapter(adapter);


    }
}
