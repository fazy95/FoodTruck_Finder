package com.example.s3639782.recyclerviewapp.View;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.s3639782.recyclerviewapp.Controller.myAdapter;
import com.example.s3639782.recyclerviewapp.Db.FoodTruckDatabaseHelper;
import com.example.s3639782.recyclerviewapp.Model.FoodTruck;
import com.example.s3639782.recyclerviewapp.Model.NotificationReceiver;
import com.example.s3639782.recyclerviewapp.Model.Tracking_FoodTruck;
import com.example.s3639782.recyclerviewapp.R;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import static android.graphics.Color.BLUE;
import static com.example.s3639782.recyclerviewapp.Model.SuggestAlert.Channel_1_ID;

public class MainActivity extends AppCompatActivity {


    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private ArrayList<FoodTruck> foodTrucks;
    private ArrayList<String> categoryNames;
    private Spinner spinner;
    private ArrayAdapter<String> adapter1;
    private ArrayList<FoodTruck> sortFoodTruck = new ArrayList<FoodTruck>();
    private RecyclerView.Adapter adapter2;
    private ArrayList<String> Lines = new ArrayList<String>();
    private ArrayList<Integer> imgID = new ArrayList<Integer>();
    private NotificationManagerCompat notificationManager;
    private ArrayList<Tracking_FoodTruck> trackingFoodTrucks = new ArrayList<Tracking_FoodTruck>();
    NotificationCompat.Builder builder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        foodTrucks = new ArrayList<>();

        notificationManager = NotificationManagerCompat.from(this);

        //Populate the list with image files

        imgID.add(R.drawable.currytruck);
        imgID.add(R.drawable.happycamper);
        imgID.add(R.drawable.ghostkitchen);
        imgID.add(R.drawable.afrofeast);
        imgID.add(R.drawable.seniorbbq);
        imgID.add(R.drawable.whiteguycooksthai);
        imgID.add(R.drawable.yogurddiction);
        imgID.add(R.drawable.banhmiboys);
        imgID.add(R.drawable.mytwomums);
        imgID.add(R.drawable.mrburger);


        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        spinner = (Spinner) findViewById(R.id.spinner);


        initData();

        Button b = (Button) findViewById(R.id.TlistButton);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent thisIntent = new Intent(MainActivity.this, Tracked.class);

                boolean isInitRequired = false;

                FoodTruckDatabaseHelper ftDbHelper1 = new FoodTruckDatabaseHelper(MainActivity.this);

                Cursor cursor1 = ftDbHelper1.getAlltracking();
                if (cursor1.getCount() <= 0) {
                    cursor1.close();
                    isInitRequired = true;
                    Toast.makeText(MainActivity.this, "The tracking list is empty", Toast.LENGTH_SHORT).show();
                } else {

                    startActivity(thisIntent);

                }

            }
        });


        //Setting foodtruck list to recycler view

        adapter = new myAdapter(foodTrucks, this);
        adapter1 = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, categoryNames);
        adapter2 = new myAdapter(sortFoodTruck, this);

        spinner.setAdapter(adapter1);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                sortFoodTruck.clear();
                if (position == 0) {
                    recyclerView.setAdapter(adapter);
                } else {
                    for (int l = 0; l < foodTrucks.size(); l++) {
                        if (foodTrucks.get(l).getCategory().equals(categoryNames.get(position))) {
                            sortFoodTruck.add(foodTrucks.get(l));
                            recyclerView.setAdapter(adapter2);
                        }

                    }

                }

            }


            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }

        });


    }

    //Initialize all static data and store in db
    private void initData() {

        categoryNames = new ArrayList<>();
        categoryNames.add("ALL");
        categoryNames.add("Asian");
        categoryNames.add("Italian");
        categoryNames.add("African");
        categoryNames.add("Argentinian");
        categoryNames.add("Thai");
        categoryNames.add("Vietnamese");
        categoryNames.add("Dessert");
        categoryNames.add("Western");

        boolean isInitRequired = false;

        FoodTruckDatabaseHelper ftDbHelper = new FoodTruckDatabaseHelper(this);

        Cursor cursor = ftDbHelper.getAllFoodTrucks();
        if (cursor.getCount() <= 0) {
            cursor.close();
            isInitRequired = true;
        } else {

            //Loop through cursor and populate foodTrucks

            fileReadFoodTruckInfo();

        }

        if (isInitRequired) {

            //Call File Read for Food Truck Info

            fileReadFoodTruckInfo();

            //Call Database function to store all food truck data

            boolean isSaved = ftDbHelper.addFoodTrucks(foodTrucks);
            //Show error is not saved in db

            if (isSaved) {
                Log.d("Database 1", "Food Truck data saved successfully in table");
            }

            //Call File Read for Tracking Service Info
            fileReadTrackingService();

            //Call Database to store all tracking info

            isSaved = false;
            isSaved = ftDbHelper.addFoodTracks(trackingFoodTrucks);
            //Show error is not saved in db
            if (isSaved) {
                Log.d("Database 2", "Food Tracking data saved successfully in table");
            }
        }

    }

    //Read food truck info from file
    private void fileReadFoodTruckInfo() {

        InputStream inputStream = getResources().openRawResource(R.raw.food_truck_data);
        String ret = "";
        String[] item = new String[2000];
        ArrayList<String> Line = new ArrayList<String>();


        try {

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                Lines.clear();
                while ((ret = bufferedReader.readLine()) != null) {
                    Lines.add(ret);

                    foodTrucks.add(new FoodTruck());
                }

            }
        } catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        int y = 0;
        int x = 0;
        for (int j = 0; j < foodTrucks.size(); j++) {
            item = Lines.get(j).split("#");


            List<String> itemList = new ArrayList<String>(Arrays.asList(item));

            Log.d("Reading 1", "Read Food Truck Data :" + itemList);


            foodTrucks.get(j).setId(itemList.get(y));
            foodTrucks.get(j).setName(itemList.get(y + 1));
            foodTrucks.get(j).setDesc(itemList.get(y + 2));
            foodTrucks.get(j).setUrl(itemList.get(y + 3));
            foodTrucks.get(j).setCategory(itemList.get(y + 4));
            int imageId = imgID.get(j);
            foodTrucks.get(j).setImage((imageId));


            x++;
        }

    }

    //Read tracking service info from file
    private void fileReadTrackingService() {
        InputStream inputStream = getResources().openRawResource(R.raw.tracking_data);
        String ret = "";
        String[] item = new String[2000];
        ArrayList<String> Line = new ArrayList<String>();


        try {

            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                Lines.clear();
                while ((ret = bufferedReader.readLine()) != null) {
                    Lines.add(ret);

                    trackingFoodTrucks.add(new Tracking_FoodTruck());
                }

            }
        } catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        int y = 0;
        int x = 0;
        for (int j = 0; j < trackingFoodTrucks.size(); j++) {
            item = Lines.get(j).split("#");

            List<String> itemList = new ArrayList<String>(Arrays.asList(item));
            Log.d("Reading 2", "Read Food Tracking Data :" + itemList);
            trackingFoodTrucks.get(j).setDatef(itemList.get(y));
            trackingFoodTrucks.get(j).setStopTime(itemList.get(y + 1));
            trackingFoodTrucks.get(j).setTrackableId(itemList.get(y + 2));
            trackingFoodTrucks.get(j).setDuration(itemList.get(y + 3));
            trackingFoodTrucks.get(j).setLatitude(itemList.get(y + 4));
            trackingFoodTrucks.get(j).setLongitude((itemList.get(y + 5)));

            x++;
        }
    }

    int i = 0;
    int time = 10;


    public void sendOnChannel(View view) {

        String notifTrackID = "";
        String notifStartTime = "";

        String ftName = "";
        String ftDesc = "";
        String ftURL = "";
        String ftcat = "";
        String ftid = "";


        FoodTruckDatabaseHelper ftDbHelper1 = new FoodTruckDatabaseHelper(MainActivity.this);
        Cursor cursor = ftDbHelper1.getAllFoodTracks();


        String startTime;

        while (cursor.moveToNext()) {

            String date = cursor.getString(1);
            String trackid = cursor.getString(2);
            startTime = cursor.getString(3);

            Log.d("Val", "b Date value is : " + date);
            Log.d("Val", "b Food truck id is : " + trackid);
            Log.d("Date", "b Start time value is : " + startTime);


            if(isToday(date)){

                Log.d("Val", "a Date value is : " + date);
                Log.d("Val", "a Food truck id is : " + trackid);
                Log.d("Date", "a Start time value is : " + startTime);

                notifStartTime = startTime;
                notifTrackID = trackid;
                break;
            }

        }

        cursor.close();


        Cursor cursor1 = ftDbHelper1.getAllFoodTrucks();
        while (cursor1.moveToNext()) {

            String foodTruckName = cursor1.getString(1);
            String foodTruckDesc = cursor1.getString(2);
            String foodTruckURL = cursor1.getString(3);
            String foodTruckCat = cursor1.getString(4);
            String foodTruckId = cursor1.getString(6);

            Log.d("Val", "b foodTruckName value is : " + foodTruckName);
            Log.d("Val", "b foodTruckDesc value is : " + foodTruckDesc);
            Log.d("Val", "b foodTruckURL value is : " + foodTruckURL);
            Log.d("Val", "b foodTruckCat value is : " + foodTruckCat);
            Log.d("Val", "b foodTruckId value is : " + foodTruckId);


            if(foodTruckId.equals(notifTrackID)){

                ftName = foodTruckName;
                ftDesc = foodTruckDesc;
                ftURL = foodTruckURL;
                ftcat = foodTruckCat;
                ftid = foodTruckId;

            }

        }



        String timeString = Integer.toString(time);

        String title = foodTrucks.get(i).getName();


        headsUpNotification(ftName, ftDesc, ftURL, ftcat, ftid, notifStartTime);

    }


    private void headsUpNotification(String ftName, String ftDesc, String ftURL, String ftcat, String ftid, String startTime) {

        int NOTIFICATION_ID = 1;
        builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.dinner)
                        .setColor(BLUE)
                        .setContentTitle(ftName)
                        .setContentText(startTime)
                        .setAutoCancel(true)
                        .setDefaults(NotificationCompat.DEFAULT_ALL)
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

        Intent truckDetailIntent = new Intent(this, Truckdetail.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);  ;
        truckDetailIntent.putExtra("name", ftName);
        truckDetailIntent.putExtra("image", "");
        truckDetailIntent.putExtra("id", ftid);
        truckDetailIntent.putExtra("desc", ftDesc);
        truckDetailIntent.putExtra("website", ftcat);
        truckDetailIntent.putExtra("category", "");

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, truckDetailIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent buttonIntent = new Intent(getBaseContext(), NotificationReceiver.class);
        buttonIntent.putExtra("notificationId", NOTIFICATION_ID);
        PendingIntent dismissIntent = PendingIntent.getBroadcast(getBaseContext(), 0, buttonIntent, 0);

        builder.addAction(android.R.drawable.ic_menu_view, "VIEW", pendingIntent);
        builder.addAction(android.R.drawable.ic_delete, "DISMISS", dismissIntent);

        buildNotification(NOTIFICATION_ID);
    }

    private void buildNotification(int NOTIFICATION_ID) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Will display the notification in the notification bar
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }



    public boolean isToday(String date) {
        Calendar today = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("dd/MM/yyyy");
        String todayDate = mdformat.format(today.getTime());


        Log.d("Date", "Your Current date is : " + todayDate);
        Log.d("Date", "Your Current date is : " + date);




        if(date.equals(todayDate)){
            Log.d("Debug", "Found Match");
            return true;
        }

        return false;
    }

}