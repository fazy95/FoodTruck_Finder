package com.example.s3639782.recyclerviewapp.Model;



public class Tracking_FoodTruck implements Tracking{

    public String trackingName;
    public String datef;
    public String trackableId;
    public String stopTime;
    public String latitude;
    public String longitude;
    public String duration;
    public String meetingTime;

    public String getDatef() {
        return datef;
    }

    public void setDatef(String datef) {
        this.datef = datef;
    }

    public String getTrackableId() {
        return trackableId;
    }

    public void setTrackableId(String trackableId) {
        this.trackableId = trackableId;
    }

    public String getStopTime() {
        return stopTime;
    }

    public void setStopTime(String stopTime) {
        this.stopTime = stopTime;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getMeetingTime() {
        return meetingTime;
    }

    public void setMeetingTime(String meetingTime) {
        this.meetingTime = meetingTime;
    }

    public String getTrackingName() {
        return trackingName;
    }

    public void setTrackingName(String trackingName) {
        this.trackingName = trackingName;
    }

    public Tracking_FoodTruck(){}

    public Tracking_FoodTruck(String trackingName, String datef, String trackableId, String stopTime, String latitude, String longitude, String duration, String meetingTime) {
        this.trackingName = trackingName;
        this.datef = datef;
        this.trackableId = trackableId;
        this.stopTime = stopTime;
        this.latitude = latitude;
        this.longitude = longitude;
        this.duration = duration;
        this.meetingTime = meetingTime;
    }
}
