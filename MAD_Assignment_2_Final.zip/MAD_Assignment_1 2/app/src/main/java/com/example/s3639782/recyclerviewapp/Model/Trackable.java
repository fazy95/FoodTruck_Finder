package com.example.s3639782.recyclerviewapp.Model;

public interface Trackable {

    public void setName();
    public String getName();

    public void setId();
    public String getId();

    public void setDesc();
    public String getDesc();

    public void setUrl();
    public String getUrl();

    public void setCategory();
    public String getCategory();

    public void setImage();
    public int getImage();
}
