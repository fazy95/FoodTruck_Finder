package com.example.s3639782.recyclerviewapp.Model;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.AlarmManagerCompat;
import android.widget.Toast;

import com.example.s3639782.recyclerviewapp.View.Truckdetail;

public class AlarmManager extends BroadcastReceiver {


    public void onReceive(Context context, Intent intent) {


        String message = intent.getStringExtra("AlarmMessage");
        String title = intent.getStringExtra("Alert");


        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();

        Intent intent2= new Intent(context, Truckdetail.class);
        intent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent2);

    }
}
