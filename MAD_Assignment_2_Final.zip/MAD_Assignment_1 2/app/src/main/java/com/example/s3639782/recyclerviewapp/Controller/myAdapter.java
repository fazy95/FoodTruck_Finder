package com.example.s3639782.recyclerviewapp.Controller;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.s3639782.recyclerviewapp.Db.FoodTruckDatabaseHelper;
import com.example.s3639782.recyclerviewapp.Model.FoodTruck;
import com.example.s3639782.recyclerviewapp.R;
import com.example.s3639782.recyclerviewapp.View.EditTracked;
import com.example.s3639782.recyclerviewapp.View.MapsActivity;
import com.example.s3639782.recyclerviewapp.View.Truckdetail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



public class myAdapter extends RecyclerView.Adapter<myAdapter.ViewHolder> {

    private List<FoodTruck> foodTrucks;
    private Context context;

    public myAdapter(List<FoodTruck> foodTrucks, Context context) {
        this.foodTrucks = foodTrucks;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item, viewGroup, false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {
        FoodTruck foodTruck = foodTrucks.get(i);
        viewHolder.textViewHead.setText(foodTruck.getName());
        viewHolder.imageView.setImageDrawable(context.getResources().getDrawable(foodTruck.getImage()));

        //Binding all the foodtruck informations to the card in recycler view

        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, Truckdetail.class);
                intent.putExtra("name", foodTrucks.get(i).getName());
                intent.putExtra("image", foodTrucks.get(i).getImage());
                intent.putExtra("id", foodTrucks.get(i).getId());
                intent.putExtra("desc", foodTrucks.get(i).getDesc());
                intent.putExtra("website", foodTrucks.get(i).getUrl());
                intent.putExtra("category", foodTrucks.get(i).getCategory());

                intent.setClass(context, Truckdetail.class);

                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return foodTrucks.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView textViewHead;
        public ImageView imageView;
        public CardView cardView;

        //Set items for each card with Image and Name

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewHead = (TextView) itemView.findViewById(R.id.textViewtruck);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);
            cardView = (CardView) itemView.findViewById(R.id.cardView);

        }}

    //Setting List for Tracking items in adapter

    public static class trackingAdapter extends RecyclerView.Adapter<trackingAdapter.ViewHolder> {

        //private List<Tracking_FoodTruck> trackingFoodTruckList;
        FoodTruck foodTruck;
        private Context context;
        private ArrayList<HashMap<String,Object>> foodTruckDataSet = new ArrayList<HashMap<String, Object>> ();

        private String lat;
        private String lng;

        public trackingAdapter(ArrayList<HashMap<String, Object>> foodTruckDataMap, Context context) {
            //this.trackingFoodTruckList = trackingFoodTruckList;
            this.context = context;
            this.foodTruckDataSet = foodTruckDataMap;
        }

        //Inflate layout for cards

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.tracking_list_item, viewGroup, false);

            return new ViewHolder(v);
        }

        //Setting information for tracking list item

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, final int i) {

            //final Tracking_FoodTruck trackingFoodTruck = trackingFoodTruckList.get(i);

            //HashMap<String, Object> trackingDataMap = trackingFoodTruckList.get(i);

            HashMap<String, Object> ftMap  = foodTruckDataSet.get(i);
            Log.d("FtMAP", "AdapterMap : " + foodTruckDataSet);
            Log.d("FtMAP", "AdapterMap of : " + i + " is " + ftMap);
            final String truckId = (String) ftMap.get("id");
            final String ftName = (String) ftMap.get("ftName");
            final String date = (String) ftMap.get("date");
            final String meetingTime = (String) ftMap.get("meetingTime");
            lat = (String) ftMap.get("latitude");
            lng = (String) ftMap.get("longitude");

            Log.d("VH", "Setting truck name to : " + ftName);
            viewHolder.foodTruckName.setText(ftName);
            Log.d("VH", "Setting date to : " + date);
            viewHolder.editDate.setText(date);
            Log.d("VH", "Setting edit time to : " + meetingTime);
            viewHolder.editTime.setText(meetingTime);


            viewHolder.routeButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Perform action on click

                    //String ftlat = trackingFoodTruck.getLatitude();
                    //String ftLong = trackingFoodTruck.getLongitude();

                    Bundle bundle = new Bundle();
                    bundle.putString("foodtruckLat", lat);
                    bundle.putString("foodtruckLong", lng);

                    Log.d("Route", "Lat and Lng values passed are : " + lat + ":" + lng);

                    Context context = v.getContext();

                    Intent editIntent = new Intent (context, MapsActivity.class);
                    editIntent.putExtras(bundle);

                    context.startActivity(editIntent);

                }
            });

            viewHolder.removeButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // Perform action on click

                    FoodTruckDatabaseHelper ftDbHelper = new FoodTruckDatabaseHelper(context);
                    int deletedRows = ftDbHelper.deleteFoodTrackingItem(date, meetingTime);

                    if(deletedRows > 0) {
                        Toast.makeText(context, "Tracking Removed, Refresh Screen", Toast.LENGTH_LONG).show();
                    }

                }
            });

            viewHolder.editButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    // Perform action on click

                    Toast.makeText(context, "Edit your preferences", Toast.LENGTH_LONG).show();

                    String name = ftName;
                    Bundle bundle = new Bundle();

                    bundle.putString("id", truckId);
                    bundle.putString("foodtruckname", name);

                    Context context = v.getContext();
                    Intent editIntent = new Intent (context, EditTracked.class);
                    editIntent.putExtras(bundle);

                    context.startActivity(editIntent);
                }
            });

            viewHolder.cardView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {


                }
            });

        }

        @Override
        public int getItemCount() {
            return foodTruckDataSet.size();
        }

        //Initializing the xml items with corresponding variables

        public class ViewHolder extends RecyclerView.ViewHolder{
            public TextView textViewHead;
            public ImageView imageView;
            public CardView cardView;

            public TextView foodTruckName;
            public TextView editTime;
            public TextView editDate;

            public Button removeButton;
            public Button editButton;
            public Button routeButton;

            public ViewHolder(@NonNull View itemView) {

                super(itemView);


                foodTruckName = (TextView) itemView.findViewById(R.id.txtTruckName);
                editDate = (TextView) itemView.findViewById(R.id.txtDate);
                editTime = (TextView) itemView.findViewById(R.id.txtEditTime);

                removeButton = (Button) itemView.findViewById(R.id.Removebutton);
                editButton = (Button) itemView.findViewById(R.id.Editbutton);
                routeButton = (Button) itemView.findViewById(R.id.Routebutton);

                cardView = (CardView) itemView.findViewById(R.id.cardView);

            }}
    }
}

