package com.example.s3639782.recyclerviewapp.Model;

public interface Tracking {
    public void setDatef(String a);
    public String getDatef();

    public void setTrackableId(String a);
    public String getTrackableId();

    public void setStopTime(String a);
    public String getStopTime();

    public void setLatitude(String a);
    public String getLatitude();

    public void setLongitude(String a);
    public String getLongitude();

    public void setDuration(String a);
    public String getDuration();

    public void setMeetingTime(String a);
    public String getMeetingTime();
}
